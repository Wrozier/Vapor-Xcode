//
//  ViewController.swift
//  IOSCupcakes
//
//  Created by William Rozier on 2/11/20.
//  Copyright © 2020 William Rozier. All rights reserved.
//

import UIKit

class ViewController: UITableViewController{
   var cupcakes = [Cupcake]()
    
        override func viewDidLoad() {
        super.viewDidLoad()
        //fecth the data with
        fetchData()
        
    }
    
    func fetchData() {
        let url = URL(string: "http://localhost:8080/cupcakes")!
        // ! force wrapps
        
        
        //passing in any data , response , or error
        URLSession.shared.dataTask(with: url) { data, response, error
            in
            guard let data = data else {
                print(error?.localizedDescription ?? "Unknown error")
                return
            }
            let decoder = JSONDecoder()
            
            if let cakes = try? decoder.decode([Cupcake].self,
                from: data) {
                DispatchQueue.main.async {
                self.cupcakes = cakes
                self.tableView.reloadData()
                print("Loaded\(cakes.count)cupcakes.")
                }
            } else {
                print("Unable to parse JSON response.")
            }
        }.resume()
    }
    
}
