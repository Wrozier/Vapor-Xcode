//
//  ContentView.swift
//  IOSCupcakes
//
//  Created by William Rozier on 2/11/20.
//  Copyright © 2020 William Rozier. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @available(iOS 13.0.0, *)
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    @available(iOS 13.0.0, *)
    static var previews: some View {
        ContentView()
    }
}
