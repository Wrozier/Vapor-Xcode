//
//  Cupcake.swift
//  IOSCupcakes
//
//  Created by William Rozier on 2/11/20.
//  Copyright © 2020 William Rozier. All rights reserved.
//

import Foundation

struct Cupcake: Codable {
    
    var id: Int
    var name: String
    var description: String
    var price: Int 
}
